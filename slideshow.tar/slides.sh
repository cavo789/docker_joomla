#!/bin/bash
clear
echo "Please wait a few seconds then surf to http://localhost:1948/slides.md"
docker run --rm -p 1948:1948 -v $(pwd):/slides -u $UID:$GID webpronl/reveal-md:latest slides.md -w --preprocessor preproc.js --template templates/index.html --css theme/beige.css
