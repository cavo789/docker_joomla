// view themes at https://highlightjs.org/static/demo/
module.exports = (markdown, options) => {
  return new Promise((resolve, reject) => {
    return resolve(
      markdown
        .split("\n")
        // Add horizontal/vertical slides based on hierarchy
        // H2 = horizontal slide
        // H3 and above = vertical slide
        .map((line, index) => {
          if (/^#{2} /.test(line)) return "\n---\n" + line;
          // horizontal break
          else if (/^#{3,} /.test(line)) return "\n----\n" + line;
          // vertical break
          else return line;
        })
        // Replace ==TEXT== by <mark>TEXT</mark>
        .map((line, index) => {
          var re = /==([^=]*)==/;
          line = line.replace(new RegExp(re, "g"), "<mark>$1</mark>");
          return line;
        })
        // Replace ++added++ by <ins>added</ins>
        .map((line, index) => {
          var re = /\+\+([^\+]*)\+\+/;
          line = line.replace(new RegExp(re, "g"), "<ins>$1</ins>");
          return line;
        })
        .join("\n")
    );
  });
};
